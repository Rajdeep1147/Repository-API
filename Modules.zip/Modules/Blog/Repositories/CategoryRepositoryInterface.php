<?php 
namespace Modules\Blog\Repositories;
use App\TestRepo\ParentRepositoryInterface;
interface CategoryRepositoryInterface extends ParentRepositoryInterface{
    
}